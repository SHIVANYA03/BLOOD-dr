"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Plus, Search } from "lucide-react"

// Mock data for blood inventory
const inventoryData = [
  {
    id: "1",
    bloodType: "A+",
    units: 45,
    status: "Adequate",
    lastUpdated: "2023-11-15",
  },
  {
    id: "2",
    bloodType: "A-",
    units: 12,
    status: "Low",
    lastUpdated: "2023-11-14",
  },
  {
    id: "3",
    bloodType: "B+",
    units: 28,
    status: "Adequate",
    lastUpdated: "2023-11-15",
  },
  {
    id: "4",
    bloodType: "B-",
    units: 8,
    status: "Critical",
    lastUpdated: "2023-11-13",
  },
  {
    id: "5",
    bloodType: "AB+",
    units: 15,
    status: "Low",
    lastUpdated: "2023-11-14",
  },
  {
    id: "6",
    bloodType: "AB-",
    units: 5,
    status: "Critical",
    lastUpdated: "2023-11-12",
  },
  {
    id: "7",
    bloodType: "O+",
    units: 52,
    status: "Adequate",
    lastUpdated: "2023-11-15",
  },
  {
    id: "8",
    bloodType: "O-",
    units: 7,
    status: "Critical",
    lastUpdated: "2023-11-13",
  },
]

export function BloodInventory() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredInventory = inventoryData.filter(
    (item) =>
      item.bloodType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Blood Inventory</CardTitle>
          <CardDescription>Manage and monitor blood units by type and status</CardDescription>
        </div>
        <Button className="bg-red-600 hover:bg-red-700">
          <Plus className="mr-2 h-4 w-4" />
          Add Units
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search inventory..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Blood Type</TableHead>
                <TableHead>Units Available</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInventory.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.bloodType}</TableCell>
                  <TableCell>{item.units}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        item.status === "Adequate" ? "default" : item.status === "Low" ? "outline" : "destructive"
                      }
                    >
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{item.lastUpdated}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem>Update Units</DropdownMenuItem>
                        <DropdownMenuItem>View History</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Set Alert Level</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
