"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Plus, Search } from "lucide-react"

// Mock data for blood requests
const requestsData = [
  {
    id: "1",
    requestedBy: "City Hospital",
    bloodType: "O-",
    requestDate: "2023-11-15",
    units: 3,
    status: "Pending",
    priority: "High",
  },
  {
    id: "2",
    requestedBy: "Memorial Medical Center",
    bloodType: "A+",
    requestDate: "2023-11-14",
    units: 2,
    status: "Approved",
    priority: "Medium",
  },
  {
    id: "3",
    requestedBy: "St. Mary's Hospital",
    bloodType: "B+",
    requestDate: "2023-11-14",
    units: 1,
    status: "Fulfilled",
    priority: "Medium",
  },
  {
    id: "4",
    requestedBy: "County General Hospital",
    bloodType: "AB+",
    requestDate: "2023-11-13",
    units: 2,
    status: "Fulfilled",
    priority: "Low",
  },
  {
    id: "5",
    requestedBy: "University Medical Center",
    bloodType: "O+",
    requestDate: "2023-11-13",
    units: 4,
    status: "Pending",
    priority: "High",
  },
  {
    id: "6",
    requestedBy: "Children's Hospital",
    bloodType: "A-",
    requestDate: "2023-11-12",
    units: 2,
    status: "Approved",
    priority: "High",
  },
  {
    id: "7",
    requestedBy: "Veterans Hospital",
    bloodType: "B-",
    requestDate: "2023-11-11",
    units: 1,
    status: "Fulfilled",
    priority: "Medium",
  },
  {
    id: "8",
    requestedBy: "Riverside Medical Center",
    bloodType: "AB-",
    requestDate: "2023-11-10",
    units: 1,
    status: "Fulfilled",
    priority: "Low",
  },
]

export function RecentRequests() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredRequests = requestsData.filter(
    (item) =>
      item.requestedBy.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.bloodType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.priority.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Blood Requests</CardTitle>
          <CardDescription>Manage and process blood requests from hospitals</CardDescription>
        </div>
        <Button className="bg-red-600 hover:bg-red-700">
          <Plus className="mr-2 h-4 w-4" />
          New Request
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search requests..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Requested By</TableHead>
                <TableHead>Blood Type</TableHead>
                <TableHead>Units</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRequests.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.requestedBy}</TableCell>
                  <TableCell>{item.bloodType}</TableCell>
                  <TableCell>{item.units}</TableCell>
                  <TableCell>{item.requestDate}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        item.priority === "High" ? "destructive" : item.priority === "Medium" ? "default" : "outline"
                      }
                    >
                      {item.priority}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        item.status === "Fulfilled" ? "default" : item.status === "Approved" ? "secondary" : "outline"
                      }
                    >
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>Update Status</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Process Request</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
