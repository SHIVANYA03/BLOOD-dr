"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  const isLoginPage = pathname.startsWith("/auth")
  const isDashboardPage = pathname.startsWith("/dashboard")

  // Don't show navbar on login or dashboard pages
  if (isLoginPage || isDashboardPage) {
    return null
  }

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    { href: "/donor/register", label: "Donate" },
    { href: "/contact", label: "Contact" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold text-red-600">BloodBank</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-red-600",
                pathname === link.href ? "text-red-600" : "text-foreground/60",
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <Button asChild variant="outline">
            <Link href="/auth/login">Staff Login</Link>
          </Button>
          <Button asChild className="bg-red-600 hover:bg-red-700">
            <Link href="/donor/register">Donate Now</Link>
          </Button>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden flex items-center">
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>

          {isOpen && (
            <div className="absolute top-16 left-0 right-0 bg-background border-b p-4 flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-red-600 py-2",
                    pathname === link.href ? "text-red-600" : "text-foreground/60",
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <div className="flex flex-col gap-2 pt-2 border-t">
                <Button asChild variant="outline" className="w-full">
                  <Link href="/auth/login" onClick={() => setIsOpen(false)}>
                    Staff Login
                  </Link>
                </Button>
                <Button asChild className="w-full bg-red-600 hover:bg-red-700">
                  <Link href="/donor/register" onClick={() => setIsOpen(false)}>
                    Donate Now
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
