import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { DropletsIcon as BloodDrop, Users, Clipboard, Activity } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-500 to-red-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Blood Bank Management System</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Efficiently manage blood donations, inventory, and requests to save more lives
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="bg-white text-red-600 hover:bg-gray-100">
              <Link href="/auth/login">Staff Login</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              <Link href="/donor/register">Register as Donor</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={<BloodDrop className="h-10 w-10 text-red-500" />}
              title="Blood Inventory"
              description="Track and manage blood units by type, collection date, and expiration"
            />
            <FeatureCard
              icon={<Users className="h-10 w-10 text-red-500" />}
              title="Donor Management"
              description="Register donors, track donation history, and manage donor information"
            />
            <FeatureCard
              icon={<Clipboard className="h-10 w-10 text-red-500" />}
              title="Request Handling"
              description="Process blood requests from hospitals and track fulfillment status"
            />
            <FeatureCard
              icon={<Activity className="h-10 w-10 text-red-500" />}
              title="Reports & Analytics"
              description="Generate insights on inventory levels, donations, and distribution"
            />
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Donate?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Your donation can save up to three lives. Register now to become a donor and help those in need.
          </p>
          <Button asChild size="lg" className="bg-red-600 hover:bg-red-700">
            <Link href="/donor/register">Register as Donor</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-10 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Blood Bank Management</h3>
              <p className="text-gray-300">Efficiently managing blood donations and distribution to save lives.</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-gray-300 hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-300 hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/donor/register" className="text-gray-300 hover:text-white">
                    Become a Donor
                  </Link>
                </li>
                <li>
                  <Link href="/auth/login" className="text-gray-300 hover:text-white">
                    Staff Login
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Contact Us</h3>
              <p className="text-gray-300">
                123 Blood Bank Street
                <br />
                City, State 12345
                <br />
                Phone: (123) 456-7890
                <br />
                Email: info@bloodbank.org
              </p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; {new Date().getFullYear()} Blood Bank Management System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <Card className="h-full">
      <CardContent className="pt-6 text-center flex flex-col items-center">
        <div className="mb-4">{icon}</div>
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  )
}
