import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { DonorsList } from "@/components/dashboard/donors-list"

export default function DonorsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Donor Management" text="View and manage blood donors and their information" />
      <DonorsList />
    </DashboardShell>
  )
}
