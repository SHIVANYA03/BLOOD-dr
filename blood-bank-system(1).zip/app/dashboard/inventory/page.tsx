import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { BloodInventory } from "@/components/dashboard/blood-inventory"

export default function InventoryPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Blood Inventory" text="Manage and track blood units by type and status" />
      <BloodInventory />
    </DashboardShell>
  )
}
