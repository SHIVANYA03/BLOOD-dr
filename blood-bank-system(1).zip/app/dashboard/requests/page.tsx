import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { RecentRequests } from "@/components/dashboard/recent-requests"

export default function RequestsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Blood Requests" text="Manage and process blood requests from hospitals and clinics" />
      <RecentRequests />
    </DashboardShell>
  )
}
