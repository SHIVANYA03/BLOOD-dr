import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"

export default function ThankYouPage() {
  return (
    <div className="container mx-auto py-20 px-4 flex items-center justify-center min-h-[calc(100vh-4rem)]">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          <CardTitle className="text-2xl">Registration Successful!</CardTitle>
          <CardDescription>Thank you for registering as a blood donor</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <p className="mb-4">
            Your information has been successfully submitted. Our team will review your application and contact you soon
            with further details about donation opportunities.
          </p>
          <p className="text-sm text-gray-600">
            Your willingness to donate blood can help save lives. We appreciate your generosity and commitment to
            helping others.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <Button asChild className="w-full bg-red-600 hover:bg-red-700">
            <Link href="/">Return to Home</Link>
          </Button>
          <Button asChild variant="outline" className="w-full">
            <Link href="/contact">Contact Us</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
