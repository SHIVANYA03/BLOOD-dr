import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">About Our Blood Bank</h1>

        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
            <p className="text-lg text-gray-700 mb-4">
              Our mission is to ensure a safe and adequate blood supply for the community we serve. We are committed to
              collecting, processing, and distributing blood and blood components to meet the needs of patients in
              hospitals and medical facilities.
            </p>
            <p className="text-lg text-gray-700">
              We strive to provide exceptional service to donors, hospitals, and patients while maintaining the highest
              standards of safety and quality.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Why Donate Blood?</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-red-50 p-6 rounded-lg">
                <h3 className="text-xl font-medium mb-2 text-red-700">Save Lives</h3>
                <p className="text-gray-700">
                  A single blood donation can save up to three lives. Blood is needed for surgeries, cancer treatments,
                  chronic illnesses, and traumatic injuries.
                </p>
              </div>
              <div className="bg-red-50 p-6 rounded-lg">
                <h3 className="text-xl font-medium mb-2 text-red-700">Always Needed</h3>
                <p className="text-gray-700">
                  Every two seconds, someone in the country needs blood. The need for blood is constant and only
                  volunteer donors can fulfill that need.
                </p>
              </div>
              <div className="bg-red-50 p-6 rounded-lg">
                <h3 className="text-xl font-medium mb-2 text-red-700">Health Benefits</h3>
                <p className="text-gray-700">
                  Donating blood can help reduce the risk of heart disease and cancer. It also helps in reducing the
                  iron stores in the body.
                </p>
              </div>
              <div className="bg-red-50 p-6 rounded-lg">
                <h3 className="text-xl font-medium mb-2 text-red-700">Free Health Check</h3>
                <p className="text-gray-700">
                  Before donating, you receive a mini health screening that checks your pulse, blood pressure, body
                  temperature, and hemoglobin levels.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Our History</h2>
            <p className="text-lg text-gray-700 mb-4">
              Established in 2005, our blood bank has been serving the community for over 15 years. What started as a
              small operation has grown into a comprehensive blood management system that serves multiple hospitals and
              medical facilities in the region.
            </p>
            <p className="text-lg text-gray-700">
              Over the years, we have collected over 100,000 units of blood and have helped save countless lives through
              our dedicated service and the generosity of our donors.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Our Team</h2>
            <p className="text-lg text-gray-700 mb-4">
              Our team consists of highly trained medical professionals, including phlebotomists, nurses, laboratory
              technicians, and administrative staff. All our staff members are certified and undergo regular training to
              ensure they provide the best care to our donors and handle blood products with the utmost care.
            </p>
          </section>

          <div className="mt-8 text-center">
            <h2 className="text-2xl font-semibold mb-4">Ready to Make a Difference?</h2>
            <Button asChild size="lg" className="bg-red-600 hover:bg-red-700">
              <Link href="/donor/register">Register as a Donor</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
