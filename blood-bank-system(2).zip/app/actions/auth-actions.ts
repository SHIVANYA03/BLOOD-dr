"use server"

// Mock user data - in a real app, this would be in a database
const users = [
  {
    id: "1",
    name: "Admin User",
    email: "admin@bloodbank.org",
    password: "password123", // In a real app, this would be hashed
    role: "admin",
  },
  {
    id: "2",
    name: "Staff User",
    email: "staff@bloodbank.org",
    password: "password123", // In a real app, this would be hashed
    role: "staff",
  },
]

export async function loginUser({ email, password }: { email: string; password: string }) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Find user with matching email and password
  const user = users.find((u) => u.email === email && u.password === password)

  if (user) {
    // In a real app, you would set a session or JWT token here
    return {
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    }
  }

  return {
    success: false,
    error: "Invalid email or password",
  }
}

export async function registerDonor(formData: FormData) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // In a real app, you would validate and save to a database
  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const phone = formData.get("phone") as string
  const bloodType = formData.get("bloodType") as string

  // Validation would happen here

  return {
    success: true,
    donor: {
      id: Math.random().toString(36).substring(2, 9),
      name,
      email,
      phone,
      bloodType,
      registeredAt: new Date().toISOString(),
    },
  }
}
