import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { RecentDonations } from "@/components/dashboard/recent-donations"

export default function DonationsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Donation Records" text="View and manage blood donation records" />
      <RecentDonations />
    </DashboardShell>
  )
}
