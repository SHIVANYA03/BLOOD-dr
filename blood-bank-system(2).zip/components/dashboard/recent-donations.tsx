"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search } from "lucide-react"
import { useState } from "react"

// Mock data for recent donations
const donationsData = [
  {
    id: "1",
    donorName: "John Smith",
    bloodType: "A+",
    donationDate: "2023-11-15",
    status: "Completed",
    units: 1,
  },
  {
    id: "2",
    donorName: "Emily Johnson",
    bloodType: "O-",
    donationDate: "2023-11-14",
    status: "Completed",
    units: 1,
  },
  {
    id: "3",
    donorName: "Michael Brown",
    bloodType: "B+",
    donationDate: "2023-11-14",
    status: "Processing",
    units: 1,
  },
  {
    id: "4",
    donorName: "Sarah Davis",
    bloodType: "AB+",
    donationDate: "2023-11-13",
    status: "Completed",
    units: 1,
  },
  {
    id: "5",
    donorName: "David Wilson",
    bloodType: "O+",
    donationDate: "2023-11-12",
    status: "Completed",
    units: 1,
  },
  {
    id: "6",
    donorName: "Jennifer Martinez",
    bloodType: "A-",
    donationDate: "2023-11-12",
    status: "Completed",
    units: 1,
  },
  {
    id: "7",
    donorName: "Robert Taylor",
    bloodType: "B-",
    donationDate: "2023-11-11",
    status: "Completed",
    units: 1,
  },
  {
    id: "8",
    donorName: "Lisa Anderson",
    bloodType: "AB-",
    donationDate: "2023-11-10",
    status: "Completed",
    units: 1,
  },
]

export function RecentDonations() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredDonations = donationsData.filter(
    (item) =>
      item.donorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.bloodType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Donations</CardTitle>
        <CardDescription>View and manage recent blood donations</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search donations..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Donor Name</TableHead>
                <TableHead>Blood Type</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Units</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDonations.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.donorName}</TableCell>
                  <TableCell>{item.bloodType}</TableCell>
                  <TableCell>{item.donationDate}</TableCell>
                  <TableCell>{item.units}</TableCell>
                  <TableCell>
                    <Badge variant={item.status === "Completed" ? "default" : "secondary"}>{item.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>Edit Record</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Print Certificate</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
