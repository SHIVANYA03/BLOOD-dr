"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Mock data for the chart
const data = [
  {
    name: "Jan",
    donations: 45,
    requests: 38,
  },
  {
    name: "Feb",
    donations: 52,
    requests: 43,
  },
  {
    name: "Mar",
    donations: 61,
    requests: 55,
  },
  {
    name: "Apr",
    donations: 67,
    requests: 62,
  },
  {
    name: "May",
    donations: 71,
    requests: 68,
  },
  {
    name: "Jun",
    donations: 56,
    requests: 51,
  },
  {
    name: "Jul",
    donations: 72,
    requests: 67,
  },
  {
    name: "Aug",
    donations: 69,
    requests: 66,
  },
  {
    name: "Sep",
    donations: 78,
    requests: 70,
  },
  {
    name: "Oct",
    donations: 87,
    requests: 82,
  },
  {
    name: "Nov",
    donations: 74,
    requests: 71,
  },
  {
    name: "Dec",
    donations: 62,
    requests: 59,
  },
]

export function Overview() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Overview</CardTitle>
        <CardDescription>Comparison of blood donations and requests over the past year</CardDescription>
      </CardHeader>
      <CardContent className="px-2">
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip />
              <Bar dataKey="donations" fill="#ef4444" radius={[4, 4, 0, 0]} name="Donations" />
              <Bar dataKey="requests" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Requests" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
