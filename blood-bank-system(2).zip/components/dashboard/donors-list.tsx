"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Plus, Search } from "lucide-react"

// Mock data for donors
const donorsData = [
  {
    id: "1",
    name: "John Smith",
    email: "john.smith@example.com",
    phone: "(555) 123-4567",
    bloodType: "A+",
    lastDonation: "2023-11-15",
    status: "Active",
    donationCount: 8,
  },
  {
    id: "2",
    name: "Emily Johnson",
    email: "emily.johnson@example.com",
    phone: "(555) 987-6543",
    bloodType: "O-",
    lastDonation: "2023-11-14",
    status: "Active",
    donationCount: 5,
  },
  {
    id: "3",
    name: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "(555) 456-7890",
    bloodType: "B+",
    lastDonation: "2023-11-14",
    status: "Active",
    donationCount: 3,
  },
  {
    id: "4",
    name: "Sarah Davis",
    email: "sarah.davis@example.com",
    phone: "(555) 234-5678",
    bloodType: "AB+",
    lastDonation: "2023-11-13",
    status: "Active",
    donationCount: 6,
  },
  {
    id: "5",
    name: "David Wilson",
    email: "david.wilson@example.com",
    phone: "(555) 876-5432",
    bloodType: "O+",
    lastDonation: "2023-11-12",
    status: "Inactive",
    donationCount: 2,
  },
  {
    id: "6",
    name: "Jennifer Martinez",
    email: "jennifer.martinez@example.com",
    phone: "(555) 345-6789",
    bloodType: "A-",
    lastDonation: "2023-11-12",
    status: "Active",
    donationCount: 4,
  },
  {
    id: "7",
    name: "Robert Taylor",
    email: "robert.taylor@example.com",
    phone: "(555) 765-4321",
    bloodType: "B-",
    lastDonation: "2023-11-11",
    status: "Active",
    donationCount: 7,
  },
  {
    id: "8",
    name: "Lisa Anderson",
    email: "lisa.anderson@example.com",
    phone: "(555) 432-1098",
    bloodType: "AB-",
    lastDonation: "2023-11-10",
    status: "Inactive",
    donationCount: 1,
  },
]

export function DonorsList() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredDonors = donorsData.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.bloodType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Donors</CardTitle>
          <CardDescription>View and manage registered blood donors</CardDescription>
        </div>
        <Button className="bg-red-600 hover:bg-red-700">
          <Plus className="mr-2 h-4 w-4" />
          Add Donor
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search donors..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Blood Type</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Last Donation</TableHead>
                <TableHead>Donations</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDonors.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.bloodType}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{item.email}</div>
                      <div className="text-muted-foreground">{item.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>{item.lastDonation}</TableCell>
                  <TableCell>{item.donationCount}</TableCell>
                  <TableCell>
                    <Badge variant={item.status === "Active" ? "default" : "secondary"}>{item.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem>View Profile</DropdownMenuItem>
                        <DropdownMenuItem>Edit Details</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Record Donation</DropdownMenuItem>
                        <DropdownMenuItem>Send Notification</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
