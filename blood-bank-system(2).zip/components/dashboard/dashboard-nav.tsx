"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart3, Droplets, Users, ClipboardList, Settings, Calendar, LogOut } from "lucide-react"

export function DashboardNav() {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: BarChart3,
    },
    {
      title: "Inventory",
      href: "/dashboard/inventory",
      icon: Droplets,
    },
    {
      title: "Donors",
      href: "/dashboard/donors",
      icon: Users,
    },
    {
      title: "Requests",
      href: "/dashboard/requests",
      icon: ClipboardList,
    },
    {
      title: "Donations",
      href: "/dashboard/donations",
      icon: Calendar,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  return (
    <nav className="grid gap-2 px-2">
      {navItems.map((item, index) => (
        <Link
          key={index}
          href={item.href}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent transition-all",
            pathname === item.href ? "bg-accent" : "transparent",
          )}
        >
          <item.icon className="h-5 w-5" />
          <span>{item.title}</span>
        </Link>
      ))}
      <div className="mt-auto">
        <Link
          href="/auth/login"
          className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent transition-all text-red-600"
        >
          <LogOut className="h-5 w-5" />
          <span>Logout</span>
        </Link>
      </div>
    </nav>
  )
}
